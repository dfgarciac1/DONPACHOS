<?php
header("Location: http://192.168.1.8:8000/LogicaN/login.php");
?>