function PaginaPr(){
<script type="text/javascript">
window.location="http://www.cristalab.com";
</script>
}